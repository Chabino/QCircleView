#!/sbin/sh
mkdir /tmp/out

dd if=/dev/block/platform/msm_sdcc.1/by-name/boot of=/tmp/boot.img || exit 1
if [ -z /tmp/boot.img ]; then exit 1; fi

/tmp/unpackbootimg -i /tmp/boot.img -o /tmp/out

if [ -e /tmp/out/boot.img-ramdisk.gz ]; then
	rdcomp=/tmp/out/boot.img-ramdisk.gz
elif [ -e /tmp/out/boot.img-ramdisk.lz4 ]; then
	rdcomp=/tmp/out/boot.img-ramdisk.lz4
else
	exit 1
fi

if grep 'androidboot\.selinux=permissive' /tmp/out/oot.img-cmdline; then
	cmdline="$(cat /tmp/out/boot.img-cmdline)"
else
	cmdline="$(cat /tmp/out/boot.img-cmdline) androidboot.selinux=permissive"
fi

/tmp/mkbootimg --kernel /tmp/out/boot.img-zImage --ramdisk $rdcomp --dt /tmp/out/boot.img-dt --cmdline "$cmdline" --pagesize $(cat /tmp/out/boot.img-pagesize) --base $(cat /tmp/out/boot.img-base) --ramdisk_offset $(cat /tmp/out/boot.img-ramdisk_offset) --tags_offset $(cat /tmp/out/boot.img-tags_offset) --output /tmp/newboot.img

if [ -z /tmp/newboot.img ]; then exit 1; fi

dd if=/tmp/bump bs=1 count=32 >> /tmp/newboot.img
dd if=/dev/zero of=/dev/block/platform/msm_sdcc.1/by-name/boot
dd if=/tmp/newboot.img of=/dev/block/platform/msm_sdcc.1/by-name/boot

exit 0
